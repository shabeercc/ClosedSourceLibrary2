//
//  ClosedSourceLibrary.h
//  ClosedSourceLibrary
//
//  Created by Shabeer on 7/3/19.
//  Copyright © 2019 Shabeer. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for ClosedSourceLibrary.
FOUNDATION_EXPORT double ClosedSourceLibraryVersionNumber;

//! Project version string for ClosedSourceLibrary.
FOUNDATION_EXPORT const unsigned char ClosedSourceLibraryVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ClosedSourceLibrary/PublicHeader.h>


